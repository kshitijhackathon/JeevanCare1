.. negbio documentation master file, created by
   sphinx-quickstart on Thu Feb  8 15:24:06 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

NegBio documentation
====================

.. toctree::
   :maxdepth: 5
   :caption: Contents:

   getting_started
   user_guide
   developer_guide
   license
   contributing
   acknowledgments
   disclaimer
   reference


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
